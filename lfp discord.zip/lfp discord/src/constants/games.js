export const Games = [
  {
    key: 'valorant',
    name: 'Valorant',
    emoji: '🟥',
    color: 0xFA4454,
    thumb: 'https://wp.logos-download.com/wp-content/uploads/2021/01/Valorant_Logo.png?dl',
    banner: 'https://i.pinimg.com/736x/10/6c/eb/106ceb85954b3223ef87cd872ad41f6c.jpg'
  },
  {
    key: 'cs2',
    name: 'CS2',
    emoji: '🟦',
    color: 0x2D6FD1,
    thumb: 'https://preview.redd.it/which-official-cs2-logo-do-you-like-better-1-or-2-v0-meakmjcylyqa1.jpg?width=358&format=pjpg&auto=webp&s=7999d040dcab80a7521b44f1d81dd840a7ef7135',
    banner: 'https://win.gg/wp-content/uploads/2023/03/CS2-1024x576.png'
  },
  {
    key: 'r6s',
    name: 'Rainbow Six Siege',
    emoji: '🟨',
    color: 0xF6C945,
    thumb: "https://m.media-amazon.com/images/I/81oJo2O-jvL._UY350_.jpg",
    banner: 'https://upload.wikimedia.org/wikipedia/fr/8/81/Tom_Clancy%27s_Rainbow_Six_Siege_Logo.png'
  },
  {
    key: 'rl',
    name: 'Rocket League',
    emoji: '🟧',
    color: 0x0DA5F1,
    thumb: 'https://pages.nichols.edu/wp-content/uploads/2019/09/158-1589516_rocket-league-png-rocket-league-logo-png.png.jpeg',
    banner: 'https://cdn2.steamgriddb.com/hero_thumb/e6da32eef072f987685b6eddca072d4f.jpg'
  },
  {
    key: 'fortnite',
    name: 'Fortnite',
    emoji: '🟪',
    color: 0x9146FF,
    thumb: 'https://upload.wikimedia.org/wikipedia/commons/7/7c/Fortnite_F_lettermark_logo.png',
    banner: 'https://ithardware.pl/artykuly/max/epic_games_pozywa_tworce_cheatow_do_fortnite-42571_1.jpg'
  },
  {
    key: 'other',
    name: 'Other',
    emoji: '⚪',
    color: 0x99AAB5,
    thumb: 'https://d1csarkz8obe9u.cloudfront.net/posterpreviews/game-zone-logo-design-template-5e9030e0d24394fd581789670dac61d7_screen.jpg?ts=1623834446',
    banner: 'https://media.discordapp.net/attachments/925088829789048842/1411129974903279656/image.png?ex=68b388b3&is=68b23733&hm=7cb4e13607f8de0a06945f61b8582c8f8307532134f56b957a334b17f42aa3c5&=&format=webp&quality=lossless'
  },
];

export const GameByKey = Object.fromEntries(Games.map(g => [g.key, g]));

export const Placeholders = {
  valorant: {
    looking: 'Initiator / Gold–Plat',
    code: 'Riot Tag (Name#1234)'
  },
  cs2: {
    looking: 'Entry / Faceit 3+',
    code: 'Lobby Code / Friend Code'
  },
  r6s: {
    looking: 'Flex / Gold 3+',
    code: 'Uplay Name'
  },
  rl: {
    looking: 'Any / Diamond+',
    code: 'Party Code'
  },
  fortnite: {
    looking: 'Ranked / Arena',
    code: 'Epic Name'
  },
  other: {
    looking: 'Role / Rank',
    code: 'Invite code / Contact'
  }
};
