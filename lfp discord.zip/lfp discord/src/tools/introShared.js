import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';
import { t } from '../i18n/index.js';

export function buildIntro(lang) {
  const embed = new EmbedBuilder()
    .setTitle(t(lang, 'introTitle'))
    .setDescription(t(lang, 'introDesc'))
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('lfp:open:new').setLabel(t(lang, 'introButton')).setStyle(ButtonStyle.Primary)
  );
  return { embed, row };
}
