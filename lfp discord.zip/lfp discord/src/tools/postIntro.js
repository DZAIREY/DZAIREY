import 'dotenv/config';
import { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { loadConfig } from '../config.js';
import { i18n, t } from '../i18n/index.js';
import { buildIntro } from './introShared.js';

const cfg = loadConfig();
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once('ready', async () => {
  try {
    const chId = cfg.channels.request;
    const channel = await client.channels.fetch(chId);
    const lang = cfg.defaultLang;
    const { embed, row } = buildIntro(lang);
    await channel.send({ embeds: [embed], components: [row] });
    console.log('Intro posted in #request-lfp');
  } catch (e) {
    console.error('Failed to post intro:', e);
  } finally {
    process.exit(0);
  }
});

client.login(cfg.token);
