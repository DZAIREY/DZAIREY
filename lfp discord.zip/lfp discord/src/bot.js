import 'dotenv/config';
import { Client, GatewayIntentBits, Partials, Collection, Events, PermissionFlagsBits, ApplicationCommandOptionType } from 'discord.js';
import { loadConfig } from './config.js';
import { handleInteraction, handleVoiceControls } from './interactions/index.js';
import { state } from './utils/state.js';

const cfg = loadConfig();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.User],
});

client.once(Events.ClientReady, (c) => {
  console.log(`Logged in as ${c.user.tag}`);
  // Auto-cleanup job: remove old LFP embeds and temp voices
  const TTL_MS = (cfg.lfp?.ttlHours ?? 5) * 60 * 60 * 1000;
  // Register guild slash commands
  const registerCommands = async () => {
    try {
      if (!cfg.guildId) return;
      await c.application.commands.set([
        {
          name: 'lfpclear',
          description: 'Purge LFP requests and temp voices (staff only)',
          defaultMemberPermissions: PermissionFlagsBits.ManageChannels.toString(),
          dmPermission: false,
          options: [
            {
              name: 'scope',
              description: 'What to clear',
              type: ApplicationCommandOptionType.String,
              required: false,
              choices: [
                { name: 'current_channel', value: 'channel' },
                { name: 'whole_guild', value: 'all' },
              ],
            },
          ],
        },
      ], cfg.guildId);
      console.log('Slash commands registered for guild', cfg.guildId);
    } catch (e) {
      console.warn('Failed to register slash commands', e);
    }
  };
  registerCommands();
  const runCleanup = async () => {
    const now = Date.now();
    for (const req of state.values()) {
      const created = req.createdAt || 0;
      if (created && now - created >= TTL_MS) {
        try {
          // Delete message if present
          if (req.channelId && req.messageId) {
            const ch = await c.channels.fetch(req.channelId).catch(() => null);
            if (ch) {
              const msg = await ch.messages?.fetch?.(req.messageId).catch(() => null);
              if (msg) await msg.delete().catch(() => {});
            }
          }
          // Delete temp voice if present
          if (req.voiceChannelId) {
            const vch = await c.channels.fetch(req.voiceChannelId).catch(() => null);
            if (vch) await vch.delete('Auto-cleanup expired LFP').catch(() => {});
          }
        } catch {}
        finally {
          state.remove(req.id);
        }
      }
    }
  };
  // Run once at startup and then every TTL period
  runCleanup();
  setInterval(runCleanup, TTL_MS);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    // Slash commands
    if (interaction.isChatInputCommand() && interaction.commandName === 'lfpclear') {
      // Staff or ManageChannels only
      const isStaffRole = cfg.roles?.staff && interaction.member?.roles?.cache?.has?.(cfg.roles.staff);
      const hasPerm = interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels) || isStaffRole;
      if (!hasPerm) {
        return interaction.reply({ content: '⛔ Staff only.', ephemeral: true });
      }
      const scope = interaction.options.getString('scope') || 'channel';
      await interaction.deferReply({ ephemeral: true });
      let countMsg = 0;
      let countVoice = 0;
      const now = Date.now();
      const toRemove = [];
      for (const req of state.values()) {
        if (scope === 'channel' && req.channelId !== interaction.channelId) continue;
        if (req.guildId !== interaction.guildId) continue;
        // delete message
        if (req.channelId && req.messageId) {
          try {
            const ch = await interaction.client.channels.fetch(req.channelId).catch(() => null);
            const msg = await ch?.messages?.fetch?.(req.messageId).catch(() => null);
            if (msg) { await msg.delete().catch(() => {}); countMsg++; }
          } catch {}
        }
        // delete voice
        if (req.voiceChannelId) {
          try {
            const vch = await interaction.client.channels.fetch(req.voiceChannelId).catch(() => null);
            if (vch) { await vch.delete('Purged by staff'); countVoice++; }
          } catch {}
        }
        toRemove.push(req.id);
      }
      toRemove.forEach(id => state.remove(id));
      return interaction.editReply({ content: `🧹 Purge done. Deleted ${countMsg} message(s), ${countVoice} voice(s). Scope: ${scope}.` });
    }
    // First, voice control buttons
    const handled = await handleVoiceControls(interaction, client, cfg);
    if (!handled) {
      await handleInteraction(interaction, client, cfg);
    }
  } catch (err) {
    console.error('Interaction error', err);
    // Ignore stale/expired interactions
    if (err?.code === 10062) return;
    if (interaction.isRepliable()) {
      try {
        if (interaction.deferred) {
          await interaction.editReply({ content: '⛔ An error occurred.' });
        } else if (interaction.replied) {
          await interaction.followUp({ content: '⛔ An error occurred.', ephemeral: true });
        } else {
          await interaction.reply({ content: '⛔ An error occurred.', ephemeral: true });
        }
      } catch {}
    }
  }
});

client.login(cfg.token);
