export const i18n = {
  en: {
    introTitle: '🎮 Looking For Party (LFP) System',
    introDesc: `Tired of trolls, spam joins, or toxic players?\nWe’ve introduced a new LFP system designed to help you find serious teammates quickly and safely.\n\n📝 How It Works\nClick the button below to open a short form asking for:\n• What are you Looking for\n• How many Players you’re looking for\n• Your Party Code\n\n📌 Where It’s Posted\nYour request will be posted automatically in 🎮 • looking-for-players so others can see and join your party.`,
    introButton: 'Submit LFP Request',
    successLive: '✅ Your LFP request is live in #looking-for-players. Good luck!',
    errors: {
      alreadyIn: 'ℹ️ You’re already in this party.',
      full: '⚠️ Party is full.',
      role: '🚫 You need the role {role} to do that.',
      closed: '⛔ This request is no longer active.',
      invalidNumber: 'Please provide a number between 1 and 4.',
    },
    joinOk: '✅ You joined the party. Have fun!',
    threadIntro: '🧵 Party thread created. Use this space to coordinate.',
    joined: '✅ {user} joined the party. ({cur}/{target})',
    left: '👋 {user} left the party. ({cur}/{target})',
    removed: '👋 {user} was removed. ({cur}/{target})',
    updated: '✅ LFP updated.',
    closedOk: '✅ Request closed. Buttons disabled.',
  },
  fr: {
    introTitle: '🎮 Looking For Party (LFP) System',
    introDesc: `Tired of trolls, spam joins, or toxic players?\nWe’ve introduced a new LFP system designed to help you find serious teammates quickly and safely.\n\n📝 How It Works\nClick the button below to open a short form asking for:\n• What are you Looking for\n• How many Players you’re looking for\n• Your Party Code\n\n📌 Where It’s Posted\nYour request will be posted automatically in 🎮 • looking-for-players so others can see and join your party.`,
    introButton: 'Submit LFP Request',
    successLive: '✅ Your LFP request is live in #looking-for-players. Good luck!',
    errors: {
      alreadyIn: 'ℹ️ You’re already in this party.',
      full: '⚠️ Party is full.',
      role: '🚫 You need the role {role} to do that.',
      closed: '⛔ This request is no longer active.',
      invalidNumber: 'Please provide a number between 1 and 4.',
    },
    joinOk: '✅ You joined the party. Have fun!',
    threadIntro: '🧵 Party thread created. Use this space to coordinate.',
    joined: '✅ {user} joined the party. ({cur}/{target})',
    left: '👋 {user} left the party. ({cur}/{target})',
    removed: '👋 {user} was removed. ({cur}/{target})',
    updated: '✅ LFP updated.',
    closedOk: '✅ Request closed. Buttons disabled.',
  },
  ar: {
    introTitle: '🎮 Looking For Party (LFP) System',
    introDesc: `Tired of trolls, spam joins, or toxic players?\nWe’ve introduced a new LFP system designed to help you find serious teammates quickly and safely.\n\n📝 How It Works\nClick the button below to open a short form asking for:\n• What are you Looking for\n• How many Players you’re looking for\n• Your Party Code\n\n📌 Where It’s Posted\nYour request will be posted automatically in 🎮 • looking-for-players so others can see and join your party.`,
    introButton: 'Submit LFP Request',
    successLive: '✅ Your LFP request is live in #looking-for-players. Good luck!',
    errors: {
      alreadyIn: 'ℹ️ You’re already in this party.',
      full: '⚠️ Party is full.',
      role: '🚫 You need the role {role} to do that.',
      closed: '⛔ This request is no longer active.',
      invalidNumber: 'Please provide a number between 1 and 4.',
    },
    joinOk: '✅ You joined the party. Have fun!',
    threadIntro: '🧵 Party thread created. Use this space to coordinate.',
    joined: '✅ {user} joined the party. ({cur}/{target})',
    left: '👋 {user} left the party. ({cur}/{target})',
    removed: '👋 {user} was removed. ({cur}/{target})',
    updated: '✅ LFP updated.',
    closedOk: '✅ Request closed. Buttons disabled.',
  },
};

export function t(lang, key, vars={}) {
  const dict = i18n[lang] || i18n.en;
  const path = key.split('.');
  let cur = dict;
  for (const k of path) cur = cur?.[k];
  let s = typeof cur === 'string' ? cur : '';
  for (const [k,v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
  return s;
}
