import { nanoid } from 'nanoid';

class LfpState {
  constructor() {
    this.requests = new Map(); // id -> data
    this.tempNew = new Map(); // userId -> { game }
    this.tempKick = new Map(); // userId -> { requestId, targetId }
  }
  create(data) {
    const id = nanoid(8);
    const req = { id, status: 'open', views: 0, members: [], ...data };
    this.requests.set(id, req);
    return req;
  }
  get(id) { return this.requests.get(id); }
  update(id, patch) {
    const r = this.get(id);
    if (!r) return null;
    Object.assign(r, patch);
    return r;
  }
  remove(id) {
    return this.requests.delete(id);
  }
  entries() {
    return this.requests.entries();
  }
  values() {
    return this.requests.values();
  }
}

export const state = new LfpState();
