export function loadConfig() {
  const cfg = {
    token: process.env.DISCORD_TOKEN,
    clientId: process.env.CLIENT_ID,
    guildId: process.env.GUILD_ID,
    channels: {
      request: process.env.CHANNEL_REQUEST_ID,
      output: process.env.CHANNEL_OUTPUT_ID,
      logs: process.env.CHANNEL_LOGS_ID,
    },
    roles: {
      staff: process.env.STAFF_ROLE_ID,
    },
    // Optional per-game output channels
    gameChannels: {
      valorant: process.env.CHANNEL_OUTPUT_VALORANT,
      cs2: process.env.CHANNEL_OUTPUT_CS2,
      r6s: process.env.CHANNEL_OUTPUT_R6S,
      rl: process.env.CHANNEL_OUTPUT_RL,
      fortnite: process.env.CHANNEL_OUTPUT_FORTNITE,
      other: process.env.CHANNEL_OUTPUT_OTHER,
    },
    // Optional per-game mention roles
    gameRoleMentions: {
      valorant: process.env.ROLE_VALORANT,
      cs2: process.env.ROLE_CS2,
      r6s: process.env.ROLE_R6S,
      rl: process.env.ROLE_RL,
      fortnite: process.env.ROLE_FORTNITE,
      other: process.env.ROLE_OTHER,
    },
    // Voice channel category (fallback) and per-game category overrides
    voiceCategories: {
      default: process.env.VOICE_CATEGORY_ID,
      valorant: process.env.VOICE_CATEGORY_VALORANT,
      cs2: process.env.VOICE_CATEGORY_CS2,
      r6s: process.env.VOICE_CATEGORY_R6S,
      rl: process.env.VOICE_CATEGORY_RL,
      fortnite: process.env.VOICE_CATEGORY_FORTNITE,
      other: process.env.VOICE_CATEGORY_OTHER,
    },
    defaultLang: process.env.DEFAULT_LANG || 'fr',
    lfp: {
      ttlHours: Number(process.env.LFP_TTL_HOURS || 5),
      bumpCooldownMin: Number(process.env.LFP_BUMP_COOLDOWN_MIN || 30),
    },
  };
  if (!cfg.token) throw new Error('Missing DISCORD_TOKEN in .env');
  if (!cfg.clientId) console.warn('CLIENT_ID not set (used by some tools)');
  return cfg;
}
