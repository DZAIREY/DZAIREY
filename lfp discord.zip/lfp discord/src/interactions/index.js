import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, ComponentType, EmbedBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionsBitField } from 'discord.js';
import { Games, GameByKey, Placeholders } from '../constants/games.js';
import { state } from '../utils/state.js';
import { t } from '../i18n/index.js';

function langFromGuild(cfg, guildId) {
  return cfg.defaultLang || 'fr';
}

function gameOptions() {
  return Games.map(g => ({ label: `${g.name} ${g.emoji}`, value: g.key }));
}

function buildIntroEmbed(lang) {
  return new EmbedBuilder()
    .setTitle(t(lang, 'introTitle'))
    .setDescription(t(lang, 'introDesc'));
}

function introButton(customId, label) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Primary)
  );
}

function buildGameSelect() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('lfp:select:game')
      .setPlaceholder('Game — Select')
      .addOptions(gameOptions())
  );
}

function buildNewModal(gameKey) {
  const lookingPH = Placeholders[gameKey]?.looking || 'Role / Rank';
  const codePH = Placeholders[gameKey]?.code || 'Invite code / Contact';
  const modal = new ModalBuilder()
    .setCustomId('lfp:modal:new')
    .setTitle('Submit LFP Request');
  const rows = [];
  if (gameKey === 'other') {
    rows.push(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('gameName').setLabel('Game Name').setPlaceholder('Enter the game name').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(40)
    ));
  }
  rows.push(new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId('looking').setLabel('Looking for (role/rank)').setPlaceholder(lookingPH).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(40)
  ));
  rows.push(new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId('players').setLabel('How many players are you looking for?').setPlaceholder('1–4').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(2)
  ));
  rows.push(new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId('code').setLabel('Enter your party code').setPlaceholder(codePH).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(60)
  ));
  rows.push(new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId('region').setLabel('Region / Server').setPlaceholder('EU West / Paris / Frankfurt').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(20)
  ));
  modal.addComponents(...rows);
  return modal;
}

function buildNoteRow() {
  return new ActionRowBuilder().addComponents(
    new TextInputBuilder().setCustomId('note').setLabel('Note (optional)').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(140)
  );
}

function formatDesc({ authorMention, looking, players, region, timestamp }) {
  // Deprecated: kept for backward compatibility if referenced elsewhere.
  return `👑 Requested By\n${authorMention}\n\n🎯 Looking for\n${looking}\n\n🧑‍🤝‍🧑 Players Needed\n${players}\n\n🌐 Region / Server\n${region || 'Any'}\n\n🕒 Posted\n${timestamp}`;
}

function buildButtons(req) {
  const viewsLabel = `👁️ ${req.views ?? 0}`;
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`lfp:code:${req.id}`).setStyle(ButtonStyle.Success).setLabel('🧾 Show Party Code'),
    new ButtonBuilder().setCustomId(`lfp:join:${req.id}`).setStyle(ButtonStyle.Primary).setLabel(req.members.length >= req.target ? 'Full' : 'Request LFP').setDisabled(req.status !== 'open' || req.members.length >= req.target),
    new ButtonBuilder().setCustomId(`lfp:views:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel(viewsLabel).setDisabled(true),
    new ButtonBuilder().setCustomId(`lfp:dmcode:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('📩 DM Code')
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`lfp:close:${req.id}`).setStyle(ButtonStyle.Danger).setLabel('Close'),
    new ButtonBuilder().setCustomId(`lfp:edit:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('Edit'),
    new ButtonBuilder().setCustomId(`lfp:kick:${req.id}`).setStyle(ButtonStyle.Danger).setLabel('Kick'),
    new ButtonBuilder().setCustomId(`lfp:bump:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('🔼 Bump')
  );
  return [row1, row2];
}

async function publishCard(client, cfg, req) {
  const perGameChannelId = cfg.gameChannels?.[req.game];
  const outChannelId = perGameChannelId || cfg.channels.output;
  const outCh = await client.channels.fetch(outChannelId);
  const game = GameByKey[req.game] || GameByKey.other;
  const displayName = req.game === 'other' ? (req.customGame?.trim() || game.name) : game.name;
  const embed = new EmbedBuilder()
    .setColor(game.color)
    .setAuthor({ name: `${displayName} ${game.emoji || ''}`.trim(), iconURL: game.thumb || undefined })
    .setTitle(`🕹️ New LFP Request — ${displayName}`)
    .addFields(
      { name: '👑 Requested By', value: `<@${req.ownerId}>`, inline: false },
      { name: '🎯 Looking for', value: req.looking, inline: true },
      { name: '🧑‍🤝‍🧑 Players Needed', value: String(req.target), inline: true },
      { name: '🌐 Region / Server', value: req.region || 'Any', inline: true },
    )
    .setFooter({ text: `LFP • ID: ${req.id}` })
    .setTimestamp(new Date());
  if (game.thumb) embed.setThumbnail(game.thumb);
  if (game.banner) embed.setImage(game.banner);

  const mentionRoleId = cfg.gameRoleMentions?.[req.game];
  const payload = mentionRoleId ? { content: `<@&${mentionRoleId}>`, embeds: [embed] } : { embeds: [embed] };
  const sent = await outCh.send(payload);
  const buttons = buildButtons(req);
  await sent.edit({ components: buttons });

  state.update(req.id, { messageId: sent.id, channelId: sent.channelId });
  return { message: sent };
}

export async function handleInteraction(interaction, client, cfg) {
  if (interaction.isButton()) {
    const id = interaction.customId;
    if (id.startsWith('lfp:open:new')) {
      const lang = langFromGuild(cfg, interaction.guildId);
      const parts = id.split(':');
      const gameKey = parts[3];
      if (gameKey && GameByKey[gameKey]) {
        state.tempNew.set(interaction.user.id, { game: gameKey });
        const modal = buildNewModal(gameKey);
        if (gameKey !== 'other') modal.addComponents(buildNoteRow());
        return interaction.showModal(modal);
      }
      return interaction.reply({ content: 'Select a game to continue:', components: [buildGameSelect()], ephemeral: true });
    }

    if (id.startsWith('lfp:code:')) {
      const reqId = id.split(':')[2];
      const req = state.get(reqId);
      if (!req || req.status !== 'open') return interaction.reply({ content: '⛔ This request is no longer active.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      req.views++;
      try {
        const msg = await interaction.channel.messages.fetch(req.messageId);
        await msg.edit({ components: buildButtons(req) });
      } catch {}
      return interaction.editReply({ content: `Party Code: ${req.code}` });
    }

    if (id.startsWith('lfp:dmcode:')) {
      const reqId = id.split(':')[2];
      const req = state.get(reqId);
      if (!req || req.status !== 'open') return interaction.reply({ content: '⛔ This request is no longer active.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      try {
        await interaction.user.send({ content: `Party Code for ${req.game === 'other' ? (req.customGame || 'Game') : (GameByKey[req.game]?.name || 'Game')}: ${req.code}` });
        return interaction.editReply({ content: '✅ Sent you a DM with the party code.' });
      } catch {
        return interaction.editReply({ content: '⚠️ I could not DM you. Please check your privacy settings.' });
      }
    }

    if (id.startsWith('lfp:bump:')) {
      const reqId = id.split(':')[2];
      const req = state.get(reqId);
      const lang = langFromGuild(cfg, interaction.guildId);
      if (!req) return interaction.reply({ content: t(lang, 'errors.closed'), ephemeral: true });
      const cooldownMin = cfg.lfp?.bumpCooldownMin ?? 30;
      const now = Date.now();
      const next = (req.bumpAt || 0) + cooldownMin * 60 * 1000;
      if (now < next) {
        const remain = Math.ceil((next - now) / 60000);
        return interaction.reply({ content: `⏳ You can bump again in ${remain} min.`, ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      try {
        const ch = await interaction.client.channels.fetch(req.channelId);
        const game = GameByKey[req.game] || GameByKey.other;
        const displayName = req.game === 'other' ? (req.customGame?.trim() || game.name) : game.name;
        const embed = new EmbedBuilder()
          .setColor(game.color)
          .setAuthor({ name: `${displayName} ${game.emoji || ''}`.trim(), iconURL: game.thumb || undefined })
          .setTitle(`🕹️ New LFP Request — ${displayName}`)
          .addFields(
            { name: '👑 Requested By', value: `<@${req.ownerId}>`, inline: false },
            { name: '🎯 Looking for', value: req.looking, inline: true },
            { name: '🧑‍🤝‍🧑 Players Needed', value: String(req.target), inline: true },
            { name: '🌐 Region / Server', value: req.region || 'Any', inline: true },
          )
          .setFooter({ text: `LFP • ID: ${req.id}` })
          .setTimestamp(new Date());
        if (game.thumb) embed.setThumbnail(game.thumb);
        if (game.banner) embed.setImage(game.banner);
        const newMsg = await ch.send({ embeds: [embed], components: buildButtons(req) });
        // delete old message if exists
        try {
          const oldCh = await interaction.client.channels.fetch(req.channelId);
          const oldMsg = await oldCh.messages.fetch(req.messageId);
          await oldMsg.delete();
        } catch {}
        state.update(req.id, { messageId: newMsg.id, channelId: newMsg.channelId, bumpAt: now });
        return interaction.editReply({ content: '🔼 Bumped!' });
      } catch (e) {
        return interaction.editReply({ content: 'Failed to bump.' });
      }
    }

    if (id.startsWith('lfp:join:')) {
      const reqId = id.split(':')[2];
      const req = state.get(reqId);
      const lang = langFromGuild(cfg, interaction.guildId);
      if (!req || req.status !== 'open') return interaction.reply({ content: t(lang, 'errors.closed'), ephemeral: true });
      if (req.members.includes(interaction.user.id) || req.ownerId === interaction.user.id) {
        return interaction.reply({ content: t(lang, 'errors.alreadyIn'), ephemeral: true });
      }
      if (req.members.length >= req.target) {
        return interaction.reply({ content: t(lang, 'errors.full'), ephemeral: true });
      }
      // If a private voice exists, request owner's approval instead of auto-joining
      if (req.voiceChannelId) {
        await interaction.deferReply({ ephemeral: true });
        try {
          const ownerUser = await interaction.client.users.fetch(req.ownerId);
          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`lfp:vctrl:approve:${req.id}:${interaction.user.id}`).setStyle(ButtonStyle.Success).setLabel(`Approve ${interaction.user.username}`),
            new ButtonBuilder().setCustomId(`lfp:vctrl:reject:${req.id}:${interaction.user.id}`).setStyle(ButtonStyle.Danger).setLabel('Reject')
          );
          await ownerUser.send({ content: `Voice access request for your party from <@${interaction.user.id}>.`, components: [row] });
          // Track pending
          const pending = new Set(req.pendingAccess || []);
          pending.add(interaction.user.id);
          state.update(req.id, { pendingAccess: [...pending] });
          return interaction.editReply({ content: '📨 Request sent to the owner for approval.' });
        } catch {
          return interaction.editReply({ content: '⚠️ Could not contact the owner. Try again later.' });
        }
      }
      // No voice exists: proceed as normal join intent
      await interaction.deferReply({ ephemeral: true });
      req.members.push(interaction.user.id);
      req.views++;
      try {
        const msg = await interaction.channel.messages.fetch(req.messageId);
        await msg.edit({ components: buildButtons(req) });
      } catch {}
      return interaction.editReply({ content: t(lang, 'joinOk') });
    }

    if (id.startsWith('lfp:close:')) {
      const reqId = id.split(':')[2];
      const req = state.get(reqId);
      const lang = langFromGuild(cfg, interaction.guildId);
      if (!req) return interaction.reply({ content: t(lang, 'errors.closed'), ephemeral: true });
      if (interaction.user.id !== req.ownerId && !interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.reply({ content: t(lang, 'errors.role', { role: 'Staff' }), ephemeral: true });
      }
      await interaction.deferReply({ ephemeral: true });
      req.status = 'closed';
      try {
        const ch = await client.channels.fetch(req.channelId);
        const msg = await ch.messages.fetch(req.messageId);
        const game = GameByKey[req.game] || GameByKey.other;
        const newEmbed = EmbedBuilder.from(msg.embeds[0]);
        newEmbed.setTitle(`[CLOSED] ${newEmbed.data.title || `🕹️ New LFP Request — ${game.name}`}`);
        await msg.edit({ embeds: [newEmbed], components: buildButtons(req) });
      } catch {}
      return interaction.editReply({ content: t(lang, 'closedOk') });
    }

    if (id.startsWith('lfp:edit:')) {
      const reqId = id.split(':')[2];
      const req = state.get(reqId);
      const lang = langFromGuild(cfg, interaction.guildId);
      if (!req) return interaction.reply({ content: t(lang, 'errors.closed'), ephemeral: true });
      if (interaction.user.id !== req.ownerId && !interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.reply({ content: t(lang, 'errors.role', { role: 'Staff' }), ephemeral: true });
      }
      const modal = new ModalBuilder().setCustomId(`lfp:modal:edit:${req.id}`).setTitle('Edit LFP');
      const rows = [];
      if (req.game === 'other') {
        rows.push(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('gameName').setLabel('Game Name').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(40).setValue(req.customGame || '')));
      }
      rows.push(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('looking').setLabel('Looking for').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(40).setValue(req.looking)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('players').setLabel('Players Needed').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(2).setValue(String(req.target))),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('code').setLabel('Party Code').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(60).setValue(req.code)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('region').setLabel('Region / Server').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(20).setValue(req.region || '')),
      );
      if (req.game !== 'other') {
        rows.push(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('note').setLabel('Note').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(140).setValue(req.note || '')));
      }
      modal.addComponents(...rows);
      return interaction.showModal(modal);
    }
  }

  if (interaction.isStringSelectMenu() && interaction.customId === 'lfp:select:game') {
    const gameKey = interaction.values[0];
    state.tempNew.set(interaction.user.id, { game: gameKey });
    const modal = buildNewModal(gameKey);
    if (gameKey !== 'other') modal.addComponents(buildNoteRow());
    return interaction.showModal(modal);
  }

  if (interaction.isModalSubmit()) {
    const id = interaction.customId;
    const lang = langFromGuild(cfg, interaction.guildId);
    if (id === 'lfp:modal:new') {
      await interaction.deferReply({ ephemeral: true });
      const temp = state.tempNew.get(interaction.user.id);
      const gameKey = temp?.game || 'other';
      const looking = interaction.fields.getTextInputValue('looking');
      const players = interaction.fields.getTextInputValue('players');
      const code = interaction.fields.getTextInputValue('code');
      const region = interaction.fields.getTextInputValue('region');
      let note = '';
      try { note = interaction.fields.getTextInputValue('note') || ''; } catch {}
      const customGame = gameKey === 'other' ? (interaction.fields.getTextInputValue('gameName') || '').trim() : '';
      if (gameKey === 'other' && !customGame) {
        return interaction.editReply({ content: 'Please enter a game name for Other.' });
      }

      const n = parseInt(players, 10);
      if (!Number.isInteger(n) || n < 1 || n > 4) {
        return interaction.editReply({ content: t(lang, 'errors.invalidNumber') });
      }

      const req = state.create({
        game: gameKey,
        ownerId: interaction.user.id,
        ownerName: interaction.user.username,
        looking,
        target: n,
        code,
        region,
        note,
        guildId: interaction.guildId,
        customGame,
        createdAt: Date.now(),
      });

      await interaction.editReply({ content: t(lang, 'successLive') });
      const { message } = await publishCard(client, cfg, req);
      state.tempNew.delete(interaction.user.id);
      // Offer to create a voice channel (ephemeral buttons)
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`lfp:voice:yes:${req.id}`).setStyle(ButtonStyle.Success).setLabel('Create Voice: Yes'),
        new ButtonBuilder().setCustomId(`lfp:voice:no:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('Create Voice: No'),
      );
      await interaction.followUp({ content: 'Create a voice channel for this party?', components: [row], ephemeral: true });
      return;
    }

    if (id.startsWith('lfp:modal:edit:')) {
      await interaction.deferReply({ ephemeral: true });
      const reqId = id.split(':').pop();
      const req = state.get(reqId);
      if (!req) return interaction.editReply({ content: t(lang, 'errors.closed') });
      if (interaction.user.id !== req.ownerId && !interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.editReply({ content: t(lang, 'errors.role', { role: 'Staff' }) });
      }
      const looking = interaction.fields.getTextInputValue('looking');
      const players = parseInt(interaction.fields.getTextInputValue('players'), 10);
      const code = interaction.fields.getTextInputValue('code');
      const region = interaction.fields.getTextInputValue('region');
      let note = '';
      try { note = interaction.fields.getTextInputValue('note') || ''; } catch {}
      let customGame = req.customGame || '';
      if (req.game === 'other') {
        customGame = (interaction.fields.getTextInputValue('gameName') || '').trim();
        if (!customGame) return interaction.editReply({ content: 'Please enter a game name for Other.' });
      }
      if (!Number.isInteger(players) || players < 1 || players > 4) {
        return interaction.editReply({ content: t(lang, 'errors.invalidNumber') });
      }
      state.update(req.id, { looking, target: players, code, region, note, customGame });
      try {
        const ch = await client.channels.fetch(req.channelId);
        const msg = await ch.messages.fetch(req.messageId);
        const game = GameByKey[req.game] || GameByKey.other;
        const displayName = req.game === 'other' ? (req.customGame?.trim() || game.name) : game.name;
        const embed = new EmbedBuilder()
          .setColor(game.color)
          .setAuthor({ name: `${displayName} ${game.emoji || ''}`.trim(), iconURL: game.thumb || undefined })
          .setTitle(`🕹️ New LFP Request — ${displayName}`)
          .addFields(
            { name: '👑 Requested By', value: `<@${req.ownerId}>`, inline: false },
            { name: '🎯 Looking for', value: req.looking, inline: true },
            { name: '🧑‍🤝‍🧑 Players Needed', value: String(req.target), inline: true },
            { name: '🌐 Region / Server', value: req.region || 'Any', inline: true },
          )
          .setFooter({ text: `LFP • ID: ${req.id}` })
          .setTimestamp(new Date());
        if (game.thumb) embed.setThumbnail(game.thumb);
        if (game.banner) embed.setImage(game.banner);
        await msg.edit({ embeds: [embed], components: buildButtons(req) });
      } catch {}
      return interaction.editReply({ content: t(lang, 'updated') });
    }
  }

  // Voice creation buttons
  if (interaction.isButton() && interaction.customId.startsWith('lfp:voice:')) {
    const parts = interaction.customId.split(':');
    const choice = parts[2];
    const reqId = parts[3];
    const req = state.get(reqId);
    const lang = langFromGuild(cfg, interaction.guildId);
    if (!req || req.status !== 'open') {
      return interaction.reply({ content: t(lang, 'errors.closed'), ephemeral: true });
    }
    if (interaction.user.id !== req.ownerId) {
      return interaction.reply({ content: 'Only the requester can create the voice channel.', ephemeral: true });
    }
    if (choice === 'no') {
      await interaction.deferUpdate();
      return interaction.followUp({ content: 'No voice channel created.', ephemeral: true });
    }
    try {
      await interaction.deferUpdate();
      const guild = interaction.guild;
      const gameCat = cfg.voiceCategories?.[req.game];
      const categoryId = gameCat || cfg.voiceCategories?.default;
      const gameLabel = req.game === 'other' ? (req.customGame?.trim() || GameByKey.other.name) : (GameByKey[req.game]?.name || 'Party');
      const channelName = `LFP ${gameLabel} — ${req.ownerName}`;
      const overwrites = [
        { id: req.ownerId, allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.Connect,
          PermissionsBitField.Flags.Speak,
          PermissionsBitField.Flags.Stream
        ] },
        { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.Connect] },
      ];
      const voice = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildVoice,
        parent: categoryId || undefined,
        permissionOverwrites: overwrites,
      });
      // Track and schedule cleanup: verify every 5 minutes; delete if owner not in voice
      state.update(req.id, { voiceChannelId: voice.id, voiceOwnerId: req.ownerId, voiceCreatedAt: Date.now() });
      const ownerId = req.ownerId;
      const voiceId = voice.id;
      const interval = setInterval(async () => {
        try {
          const ch = await guild.channels.fetch(voiceId).catch(() => null);
          if (!ch || ch.type !== ChannelType.GuildVoice) { clearInterval(interval); state.update(req.id, { voiceCleanupIntervalId: undefined }); return; }
          const ownerInChannel = ch.members?.has(ownerId);
          // Delete if owner left OR channel stayed empty for >=10 minutes
          const isEmpty = (ch.members?.size || 0) === 0;
          const now = Date.now();
          if (isEmpty) {
            const emptySince = req.voiceEmptySince || now;
            if (!req.voiceEmptySince) state.update(req.id, { voiceEmptySince: emptySince });
            if (now - emptySince >= 10 * 60 * 1000) {
              await ch.delete('Auto-cleanup: empty for 10 minutes');
              clearInterval(interval);
              state.update(req.id, { voiceCleanupIntervalId: undefined, voiceEmptySince: undefined });
              return;
            }
          } else if (req.voiceEmptySince) {
            state.update(req.id, { voiceEmptySince: undefined });
          }
          if (!ownerInChannel) {
            await ch.delete('Auto-cleanup: requester not present');
            clearInterval(interval);
            state.update(req.id, { voiceCleanupIntervalId: undefined, voiceEmptySince: undefined });
          }
        } catch (e) {
          console.error('Voice cleanup error', e);
        }
      }, 5 * 60 * 1000);
      state.update(req.id, { voiceCleanupIntervalId: interval });
      // Send a welcome/interface embed to the voice channel's text chat if available; fallback to output channel
      try {
        const outCh = voice.isTextBased() ? voice : await guild.channels.fetch(req.channelId);
        const welcome = new EmbedBuilder()
          .setColor(0x2b2d31)
          .setAuthor({ name: 'Temp Voice', iconURL: guild.iconURL?.() || undefined })
          .setDescription(`Welcome to your space, <@${req.ownerId}>.\nThis is your reflection — keep it clean.`);
        const panel = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle('TempVoice Interface')
          .setDescription('Use the buttons below to manage this temporary voice channel.')
          .addFields(
            { name: 'Channel', value: `<#${voice.id}>`, inline: true },
            { name: 'Owner', value: `<@${req.ownerId}>`, inline: true },
            { name: 'Note', value: req.note || '—', inline: false },
          );
        const controls = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`lfp:vctrl:lim-:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('Limit -'),
          new ButtonBuilder().setCustomId(`lfp:vctrl:lim+:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('Limit +'),
          new ButtonBuilder().setCustomId(`lfp:vctrl:priv:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('Privacy'),
          new ButtonBuilder().setCustomId(`lfp:vctrl:add:${req.id}`).setStyle(ButtonStyle.Success).setLabel('Add'),
          new ButtonBuilder().setCustomId(`lfp:vctrl:kick:${req.id}`).setStyle(ButtonStyle.Danger).setLabel('Kick'),
        );
        const controls2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`lfp:vctrl:block:${req.id}`).setStyle(ButtonStyle.Danger).setLabel('Block'),
          new ButtonBuilder().setCustomId(`lfp:vctrl:unblock:${req.id}`).setStyle(ButtonStyle.Secondary).setLabel('Unblock'),
          new ButtonBuilder().setCustomId(`lfp:vctrl:del:${req.id}`).setStyle(ButtonStyle.Danger).setLabel('Delete'),
        );
        await outCh.send({ embeds: [welcome, panel], components: [controls, controls2] });
      } catch {}
      return interaction.followUp({ content: `Voice channel created: <#${voice.id}>`, ephemeral: true });
    } catch (e) {
      console.error('Create voice error', e);
      return interaction.followUp({ content: 'Failed to create voice channel. Check my permissions and category configuration.', ephemeral: true });
    }
  }
}

// Voice control handlers
export async function handleVoiceControls(interaction, client, cfg) {
  const isVctrl = (id) => typeof id === 'string' && id.startsWith('lfp:vctrl:');
  if (!(interaction.isButton() || interaction.isModalSubmit() || interaction.isStringSelectMenu())) return false;
  const id = interaction.customId;
  if (!isVctrl(id)) return false;

  const parts = id.split(':');
  const type = parts[2]; // lim-, lim+, priv, del, add, kick, block, unblock, approve, reject, modal, sel
  const reqId = parts[3] || (interaction.isModalSubmit() ? id.split(':').pop() : undefined);
  const req = state.get(reqId);
  const lang = langFromGuild(cfg, interaction.guildId);

  // basic existence checks for all actions except when reqId not yet parseable
  if (!req || !req.voiceChannelId) {
    await interaction.reply({ content: 'Voice not found for this request.', ephemeral: true });
    return true;
  }
  // Permission: requester or staff
  const isOwner = interaction.user.id === req.ownerId;
  const isStaff = interaction.member?.permissions?.has(PermissionsBitField.Flags.ManageChannels);
  if (!isOwner && !isStaff) {
    await interaction.reply({ content: t(lang, 'errors.role', { role: 'Staff' }), ephemeral: true });
    return true;
  }

  try {
    const guild = interaction.guild || (req?.guildId ? await interaction.client.guilds.fetch(req.guildId).catch(() => null) : null);
    const voice = await guild.channels.fetch(req.voiceChannelId);
    if (!voice || voice.type !== ChannelType.GuildVoice) {
      await interaction.reply({ content: 'Voice channel no longer exists.', ephemeral: true });
      return true;
    }

    // Button actions
    if (interaction.isButton()) {
      if (type === 'approve' || type === 'reject') {
        // Approve/Reject a pending join request to the temp voice
        const targetId = parts[4];
        if (interaction.user.id !== req.ownerId) {
          return interaction.reply({ content: 'Only the owner can approve/reject.', ephemeral: true });
        }
        const pending = new Set(req.pendingAccess || []);
        if (!pending.has(targetId)) {
          return interaction.reply({ content: 'Request is no longer pending.', ephemeral: true });
        }
        if (type === 'approve') {
          await voice.permissionOverwrites.edit(targetId, { ViewChannel: true, Connect: true, Speak: true });
          try { const u = await interaction.client.users.fetch(targetId); await u.send(`✅ You have been approved to join <#${voice.id}>.`); } catch {}
          pending.delete(targetId);
          state.update(req.id, { pendingAccess: [...pending] });
          return interaction.reply({ content: `Approved <@${targetId}>. They can now connect.`, ephemeral: true });
        } else {
          // optionally deny connect explicitly
          await voice.permissionOverwrites.edit(targetId, { Connect: false });
          try { const u = await interaction.client.users.fetch(targetId); await u.send(`❌ Your request to join <#${voice.id}> was rejected by the owner.`); } catch {}
          pending.delete(targetId);
          state.update(req.id, { pendingAccess: [...pending] });
          return interaction.reply({ content: `Rejected <@${targetId}>.`, ephemeral: true });
        }
      }
      if (type === 'del') {
        if (req.voiceCleanupIntervalId) {
          try { clearInterval(req.voiceCleanupIntervalId); } catch {}
          state.update(req.id, { voiceCleanupIntervalId: undefined });
        }
        await voice.delete('Owner/Staff deleted via interface');
        return interaction.reply({ content: 'Voice channel deleted.', ephemeral: true });
      }
      if (type === 'priv') {
        const everyone = guild.roles.everyone.id;
        const deniedConnect = voice.permissionOverwrites.cache.get(everyone)?.deny?.has(PermissionsBitField.Flags.Connect);
        await voice.permissionOverwrites.edit(everyone, { Connect: deniedConnect ? null : false });
        return interaction.reply({ content: deniedConnect ? 'Privacy disabled (unlocked).' : 'Privacy enabled (locked).', ephemeral: true });
      }
      if (type === 'lim-' || type === 'lim+') {
        const current = voice.userLimit || 0;
        let next = current;
        if (type === 'lim-') next = Math.max(0, current - 1);
        if (type === 'lim+') next = Math.min(99, current + 1);
        if (next === current) {
          return interaction.reply({ content: `Limit unchanged (${current === 0 ? 'unlimited' : current}).`, ephemeral: true });
        }
        await voice.setUserLimit(next);
        return interaction.reply({ content: `User limit set to ${next === 0 ? 'unlimited' : next}.`, ephemeral: true });
      }
      if (type === 'add') {
        const modal = new ModalBuilder()
          .setCustomId(`lfp:vctrl:modal:add:${req.id}`)
          .setTitle('Add Member Access')
          .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user').setLabel('User mention or ID').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('@user or ID'))
          );
        return interaction.showModal(modal);
      }
      if (type === 'block' || type === 'unblock') {
        const modal = new ModalBuilder()
          .setCustomId(`lfp:vctrl:modal:${type}:${req.id}`)
          .setTitle(type === 'block' ? 'Block Member' : 'Unblock Member')
          .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user').setLabel('User mention or ID').setStyle(TextInputStyle.Short).setRequired(true))
          );
        return interaction.showModal(modal);
      }
      if (type === 'kick') {
        const opts = [...voice.members.values()].filter(m => m.id !== req.ownerId).map(m => ({ label: m.user.username, value: m.id }));
        if (opts.length === 0) return interaction.reply({ content: 'No members to kick.', ephemeral: true });
        const row = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder().setCustomId(`lfp:vctrl:sel:kick:${req.id}`).setPlaceholder('Select member to kick').addOptions(opts)
        );
        return interaction.reply({ content: 'Select a member to kick:', components: [row], ephemeral: true });
      }
    }

    // Modal submits
    if (interaction.isModalSubmit() && id.startsWith('lfp:vctrl:modal:')) {
      const action = parts[3]; // add | block | unblock
      const reqFromId = parts[4];
      const input = interaction.fields.getTextInputValue('user');
      const match = input.match(/\d{10,}/) || input.match(/<@!?([0-9]+)>/);
      const userId = match ? (match[1] || match[0]) : null;
      if (!userId) return interaction.reply({ content: 'Invalid user. Provide a mention or ID.', ephemeral: true });
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member) return interaction.reply({ content: 'User not found in this guild.', ephemeral: true });
      if (action === 'add') {
        await voice.permissionOverwrites.edit(member.id, { ViewChannel: true, Connect: true, Speak: true });
        return interaction.reply({ content: `Access granted to <@${member.id}>.`, ephemeral: true });
      }
      if (action === 'block') {
        if (member.voice?.channelId === voice.id) {
          await member.voice.disconnect('Blocked from this temporary voice');
        }
        await voice.permissionOverwrites.edit(member.id, { Connect: false });
        return interaction.reply({ content: `Blocked <@${member.id}> from joining.`, ephemeral: true });
      }
      if (action === 'unblock') {
        await voice.permissionOverwrites.edit(member.id, { Connect: null });
        return interaction.reply({ content: `Unblocked <@${member.id}>.`, ephemeral: true });
      }
    }

    // Select menu for kick
    if (interaction.isStringSelectMenu() && id.startsWith('lfp:vctrl:sel:kick:')) {
      const targetId = interaction.values[0];
      const member = await guild.members.fetch(targetId).catch(() => null);
      if (!member) return interaction.reply({ content: 'Member not found.', ephemeral: true });
      if (member.voice?.channelId !== voice.id) return interaction.reply({ content: 'Member is not in this voice.', ephemeral: true });
      await member.voice.disconnect('Kicked by owner/staff');
      return interaction.reply({ content: `Kicked <@${member.id}> from the voice.`, ephemeral: true });
    }

  } catch (e) {
    console.error('Voice control error', e);
    return interaction.reply({ content: 'Failed to update voice channel.', ephemeral: true });
  }
  return true;
}
