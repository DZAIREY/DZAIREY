# LFP Cards Discord Bot

Multi-game, multilingual (fr/en/ar) LFP Cards system using discord.js v14.

## Features
- Read-only `#request-lfp` with intro embed + button (custom_id: `lfp:open:new`)
- 2-step flow: Button → Game select (ephemeral) → Modal (exact labels)
- Publishes LFP card to `#looking-for-players` with embed colors, buttons, and auto thread
- Buttons: Show Party Code (ephemeral), Request LFP (join), Views counter, Open Thread link
- Owner/Staff controls: Edit, Kick, Close (Close implemented; Edit implemented; Kick placeholder TBD)
- States: open, full (button disabled), closed (title prefixed [CLOSED])
- i18n basics (fr, en, ar) with `DEFAULT_LANG`

## Requirements
- Node.js 18.17+
- Discord bot with Privileged Gateway Intents (Members, Message Content recommended)

## Setup
1) Clone this folder, then install dependencies:
```bash
npm install
```

2) Create `.env` from the example:
```
cp .env.example .env
```
Fill values:
- `DISCORD_TOKEN` — your bot token
- `GUILD_ID` — target guild
- `CHANNEL_REQUEST_ID` — #request-lfp channel ID (read-only for members)
- `CHANNEL_OUTPUT_ID` — #looking-for-players channel ID
- `CHANNEL_LOGS_ID` — staff logs channel ID (future use)
- `STAFF_ROLE_ID` — staff role (optional, currently permission check uses ManageChannels)
- `DEFAULT_LANG` — fr | en | ar

3) Post the intro message into `#request-lfp`:
```bash
npm run postintro
```

4) Run the bot:
```bash
npm run start
```

## Notes
- Discord modals do not support select menus; we use an ephemeral select first, then a modal with the exact field labels and placeholders.
- To force a specific game by channel, create a different intro button per channel and set custom_id like `lfp:open:new:valorant`, `...:cs2`, etc. The handler already supports this.
- Make `#request-lfp` read-only for @everyone. Only the bot should be able to send messages there.

## Roadmap
- Kick modal and logic + logs per action
- Expiration timer and [EXPIRED] state
- Per-guild language selection and better i18n coverage of all strings
